import React from 'react'

function GreenLionDistribution() {
  return (
    <div>
      GreenLionDistribution
    </div>
  )
}

export default GreenLionDistribution
