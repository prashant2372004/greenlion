import React from 'react'

function BulkPurchasePage() {
  return (
    <div>
      BulkPurchasePage
    </div>
  )
}

export default BulkPurchasePage
