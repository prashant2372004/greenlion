import React from 'react'

function BlogPage() {
  return (
    <div>
      BlogPage
    </div>
  )
}

export default BlogPage;
