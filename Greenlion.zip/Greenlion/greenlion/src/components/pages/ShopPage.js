import React from 'react'

function ShopPage() {
  return (
    <div>
      ShopPage
    </div>
  )
}

export default ShopPage
