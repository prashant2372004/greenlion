import React from "react";
import NavigationBar from "../Navbar/NavigationBar"; // Assuming Example function is moved to NavigationBar.js
import Footer from "../Footer/Footer"; // Assuming Example function is moved to NavigationBar.js
import Home from "../Home/Home";
import GroomingProducts from "../Shop/category/GroomingProducts";

function HomePage() {
  return (
    <>
      <NavigationBar />
      <Home></Home>
      <GroomingProducts></GroomingProducts>
      <Footer></Footer>
        </>
  );
}

export default HomePage;
