import React from 'react'

function BulkPurchase() {
  return (
    <div>
      BulkPurchase
    </div>
  )
}

export default BulkPurchase
