import React from "react";
import { Link } from "react-router-dom";
const GroomingProducts = () => {
  // Example data for grooming products
  const products = [
    {
      id: 1,
      name: "Beard Trimmer",
      price: "₹2,499",
      image: "path/to/beard-trimmer.jpg", // Replace with actual image path
    },
    {
      id: 2,
      name: "Shaving Cream",
      price: "₹299",
      image: "path/to/shaving-cream.jpg", // Replace with actual image path
    },
    {
      id: 3,
      name: "Aftershave Lotion",
      price: "₹499",
      image: "path/to/aftershave-lotion.jpg", // Replace with actual image path
    },
  ];

  return (
    <div style={{ backgroundColor: "#E9ECEF" }} className="py-8">
      <div className="container mx-auto px-4">
        <h1 className="text-2xl font-bold mb-6">Grooming Products</h1>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <div
              key={product.id}
              className="bg-white p-4 rounded shadow hover:shadow-lg transition-shadow"
            >
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-48 object-cover rounded mb-4"
              />
              <h2 className="text-lg font-semibold">{product.name}</h2>
              <p className="text-gray-700">{product.price}</p>
              <button
                onClick={() => alert(`Clicked on ${product.name}`)}
                className="mt-4 bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
              >
                View Details
              </button>
            </div>
          ))}
        </div>
      </div>
      <div style={{ backgroundColor: "#E9ECEF" }} className="py-8">
      <div className="container mx-auto px-4">
        <h1 className="text-xl font-bold mb-6">Welcome to GreenLion</h1>
        {/* Grooming Products Section */}
        <Link to="/shop/category/grooming-products-68" className="block">
          <img
            src="path/to/grooming-banner.jpg" // Replace with an actual banner image
            alt="Grooming Products"
            className="w-full h-auto rounded shadow hover:shadow-lg transition-shadow"
          />
        </Link>
      </div>
    </div>
    </div>
  );
};

export default GroomingProducts;
