// components/Home/HomePage.js
import React from "react";

function HomePage() {
  return <div>Home</div>;
}

export default HomePage;
