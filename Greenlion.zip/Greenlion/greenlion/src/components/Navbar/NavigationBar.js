import React, { useState } from 'react';
import { Disclosure } from "@headlessui/react";
import { Bars3Icon, XMarkIcon } from "@heroicons/react/24/outline";
import { Link } from "react-router-dom"; // Import Link for routing
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCartShopping } from '@fortawesome/free-solid-svg-icons';
import { faMagnifyingGlass } from '@fortawesome/free-solid-svg-icons';
import "./NavigationBar.css";


const navigation = [
  { name: "Home", href: "/", current: true },
  { name: "Shop", href: "/shop", current: false },
  { name: "Bulk Purchase", href: "/bulk-purchase", current: false },
  { name: "About", href: "/about", current: false },
  { name: "Blog", href: "/blog", current: false },
  { name: "Contact Us", href: "/contact-us", current: false },
];

function classNames(...classes) {
  return classes.filter(Boolean).join(" ");
}


function NavigationBar() {
  const [isVisible, setIsVisible] = useState(false);

  const togglePopover = () => {
    setIsVisible((prev) => !prev);
  };
  const [isOpen, setIsOpen] = useState(false);

  const toggleDropdown = () => {
    setIsOpen((prev) => !prev);
  };

  return (
    <Disclosure as="nav" className="bg-transparent text-black bg-gray-100">
      {({ open }) => (
        <>
          <div className="mx-auto max-w-7xl px-2 sm:px-6 lg:px-8">
            <div className="relative flex h-16 items-center justify-between">
              <div className="absolute inset-y-0 left-0 flex items-center sm:hidden">
                <Disclosure.Button className="inline-flex items-center justify-center p-2 text-gray-400 hover:bg-gray-700 hover:text-white focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white">
                  <span className="sr-only">Open main menu</span>
                  {open ? (
                    <XMarkIcon className="block h-6 w-6" aria-hidden="true" />
                  ) : (
                    <Bars3Icon className="block h-6 w-6" aria-hidden="true" />
                  )}
                </Disclosure.Button>
              </div>
              <div className="flex flex-1 items-center justify-center sm:items-stretch sm:justify-start">
                <div className="flex shrink-0 items-center">
                  <img
                    alt="Logo"
                    src="https://www.greenlion.net/web/image/website/8/logo/Green%20Lion?unique=48619bb"
                    className="h-8 w-auto"
                  />
                </div>
                <div className="hidden sm:block sm:ml-6">
                  <div className="flex space-x-4">
                    {navigation.map((item) => (
                      <Link
                        key={item.name}
                        to={item.href} // Use Link's `to` prop for navigation
                        className={classNames(
                          item.current
                            ? "text-black font-bold"
                            : "text-gray-700 hover:text-black",
                          "rounded-md px-3 py-2 text-sm font-medium"
                        )}
                      >
                        {item.name}
                      </Link>
                    ))}

                    <div className="relative">
                      {/* Button to toggle popover */}
                      <button
                        onClick={togglePopover}
                        className=" text-black  font-bold  px-4 py-2 rounded"
                      >
                        <i class="fa-solid fa-plus"></i>

                      </button>

                      {/* Popover */}
                      <div
                        className={`absolute mt-2 transition-opacity duration-500 ${isVisible ? "opacity-100" : "opacity-0 pointer-events-none"
                          } bg-gray-100 p-4 rounded shadow-lg`}
                      >
                        <Link to="/GreenLionDistribution">Distributer</Link>
                      </div>
                    </div>

                    <div className="flex items-center space-x-4">
                      <div className="flex items-center px-4 py-2 text-sm font-medium text-black bg-white border border-gray-300 rounded-full hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200">
                      <Link to="/cart">
  <FontAwesomeIcon icon={faCartShopping} className="text-gray-700" />
</Link>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center px-4 py-2 text-sm font-medium text-black bg-white border border-gray-300 rounded-full hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200">
                      <Link to="/search">
  <FontAwesomeIcon icon={faMagnifyingGlass} className="text-gray-700" />
</Link>
                      </div>
                    </div>


                    <div className="relative">
  {/* Dropdown Button */}
  <button
    className="flex items-center px-4 py-2 text-sm font-medium text-black bg-white border border-gray-300 rounded-full hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200"
    type="button"
    onClick={toggleDropdown}
  >
    English (US)
    <svg
      className="w-4 h-4 ml-2"
      aria-hidden="true"
      xmlns="http://www.w3.org/2000/svg"
      fill="none"
      viewBox="0 0 10 6"
    >
      <path
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="2"
        d="m1 1 4 4 4-4"
      />
    </svg>
  </button>

  {/* Dropdown Menu */}
  {isOpen && (
    <div className="absolute mt-2 w-48 bg-white border border-gray-300 rounded shadow-lg z-50">
      <ul>
        <li className="px-4 py-2 hover:bg-gray-100 cursor-pointer">English (US)</li>
        <li className="px-4 py-2 hover:bg-gray-100 cursor-pointer">French</li>
        <li className="px-4 py-2 hover:bg-gray-100 cursor-pointer">Spanish</li>
      </ul>
    </div>
  )}
</div>



                    <div className="flex justify-end">
                      <button
                        type="button"
                        className="flex items-center px-4 py-2 text-sm font-medium text-black bg-white border border-gray-300 rounded-full hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200"
                      >
                      <Link to="/Signin">  Sign in</Link>
                      </button>
                    </div>


                  </div>
                </div>
              </div>
            </div>
          </div>

          <Disclosure.Panel className="sm:hidden">
            <div className="space-y-1 px-2 pb-3 pt-2">
              {navigation.map((item) => (
                <Disclosure.Button
                  key={item.name}
                  as={Link} // Use Link for routing in the mobile menu
                  to={item.href}
                  className={classNames(
                    item.current
                      ? "text-black font-bold"
                      : "text-gray-700 hover:bg-gray-700 hover:text-white",
                    "block rounded-md px-3 py-2 text-base font-medium"
                  )}
                >
                  {item.name}
                </Disclosure.Button>
              ))}
            </div>
          </Disclosure.Panel>
        </>
      )}
    </Disclosure>
  );
}

export default NavigationBar;
