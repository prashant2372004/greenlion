import React from "react";
import {
  FaFacebookF,
  FaInstagram,
  FaTwitter,
  FaTelegramPlane,
} from "react-icons/fa"; // Social
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"; media icons
import { MdOutlineEmail, MdOutlinePrivacyTip, MdPolicy } from "react-icons/md"; // Email icon
import { HiOutlineArrowRight } from "react-icons/hi"; // List icons
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPlane, faShieldAlt, faFileAlt, faFlag } from "@fortawesome/free-solid-svg-icons";
import { AiOutlineFileText } from "react-icons/ai";
import { IoMdRibbon } from "react-icons/io";
import { BsShieldCheck } from "react-icons/bs";

const Footer = () => {
  return (
    <footer className="bg-gray-100 text-gray-700">
      {/* Main Footer Content */}
      <div className="container mx-auto px-4 py-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-8">
        {/* Quick Access Section */}
        <div>
          <h3 className="font-bold text-lg mb-4">Quick Access</h3>
          <ul className="space-y-2 text-lime-900">
            <li className="flex items-center">
              <HiOutlineArrowRight className="mr-2" /> Order Status
            </li>
            <li className="flex items-center">
              <HiOutlineArrowRight className="mr-2" /> Sign in
            </li>
            <li className="flex items-center">
              <HiOutlineArrowRight className="mr-2" /> Register an Account
            </li>
            <li className="flex items-center">
              <HiOutlineArrowRight className="mr-2" /> Password Recovery
            </li>
            <li className="flex items-center">
              <HiOutlineArrowRight className="mr-2" /> Warranty Request
            </li>
            <li className="flex items-center">
              <HiOutlineArrowRight className="mr-2" /> Download App
            </li>
          </ul>
        </div>

        {/* Company Section */}
        <div>
          <h3 className="font-bold text-lg mb-4">Company</h3>
          <ul className="space-y-2 text-lime-900">
            <li className="flex items-center">
              <HiOutlineArrowRight className="mr-2" /> Why Purchase Directly
            </li>
            <li className="flex items-center">
              <HiOutlineArrowRight className="mr-2" /> Bulk Purchase
            </li>
            <li className="flex items-center">
              <HiOutlineArrowRight className="mr-2" /> FAQs
            </li>
            <li className="flex items-center">
              <HiOutlineArrowRight className="mr-2" /> Contact Us
            </li>
            <li className="flex items-center">
              <HiOutlineArrowRight className="mr-2" /> About Us
            </li>
            <li className="flex items-center">
              <HiOutlineArrowRight className="mr-2" /> Blogs
            </li>
          </ul>
        </div>

        {/* Terms and Policies Section */}
        <div>
       
          <div>
          <h3 className="font-bold text-lg mb-4">Terms and Policies</h3>
      <ul className="space-y-2 text-lime-900">
        <li className="flex items-center">
          <FontAwesomeIcon icon={faPlane} className="mr-2" /> Shipping Policy
        </li>
        <li className="flex items-center">
          <MdPolicy className="mr-2" /> Refund Policy
        </li>
        <li className="flex items-center">
          <FontAwesomeIcon icon={faShieldAlt} className="mr-2" /> Warranty Policy
        </li>
        <li className="flex items-center">
          <FontAwesomeIcon icon={faFlag} className="mr-2" /> TDRA Certificate
        </li>
        
            <li className="flex items-center text-lime-900">
              <MdOutlinePrivacyTip className="mr-2" /> Privacy Policy
            </li>
            <li className="flex items-center">
              <BsShieldCheck className="mr-2" /> Warranty Policy
            </li>
            <li className="flex items-center text-lime-900">
              <AiOutlineFileText className="mr-2" /> Terms of Service
            </li>
            <li className="flex items-center text-lime-900">
              <IoMdRibbon className="mr-2" /> Warranty Claim
            </li>
            <li className="flex items-center">
              <BsShieldCheck className="mr-2" /> 24 Months Warranty
            </li>
            
      </ul>
        </div>

        </div>

        {/* Get in Touch Section */}
        <div>
          <h3 className="font-bold text-lg mb-4">Get in Touch</h3>
          {/* Social Media Icons */}
          <div className="flex space-x-4 mb-4 text-lime-900 text-xl">
            {/* Replace with actual links */}
            <FaFacebookF />
            <FaInstagram />
            <FaTwitter />
            <FaTelegramPlane />
          </div>

          {/* Contact Email */}
          <p><MdOutlineEmail size={20} style={{ display: "inline-block", marginRight: "8px" }} /> Sales@greenlion.net</p>
        </div>

        {/* About Green Lion Section */}
        <div>
          {/* About Description */}
          <h3 className="font-bold text-lg mb-4">About Green Lion</h3>
          {/* Description */}
          <p>Green Lion is a leading mobile accessory manufacturing brand with an advanced production system. The brand also offers smart home and office appliances to broaden its manufacturing scope.</p>

          {/* Address */}
          <p>9099 Leslie St Unit C, Richmond Hill, ON L4B 1K9, Canada.</p>

          {/* Payment Methods */}
          <div className="flex space-x-4 mt-4 text-gray-600 text-xl">
            {/* Replace with actual payment method icons */}
            🛒 💳 🏦 🖥️
          </div>
        </div>
      </div>

      {/* Footer Bottom Section */}
      <div className="bg-gray-200 py-4 text-center text-sm font-medium text-gray-500">
        © 2025 Green Lion. All rights reserved.
      </div>
    </footer>
  );
};

export default Footer;
