import React from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

// Importing images
import blenderImage from "../img/Green Lion Blenders.webp";
import bottlesImage from "../img/Green Lion Bottles.webp";
import christmasBanner from "../img/Green Lion Christmas Banner 2025 - Desktop Version - 1900 x 750 copy.webp";
import earbudsImage from "../img/Green Lion Earbuds.webp";
import gimbalImage from "../img/Green Lion Gimbal (1).webp";
import watchImage from "../img/Green Lion Smart Watch.webp";
import warrantyImage from "../img/green-lion-warranty (1).webp";

// Custom Next Arrow
function NextArrow(props) {
  const { className, style, onClick } = props;
  return (
    <div
      className={className}
      style={{
        ...style,
        display: "block",
        borderRadius: "50%",
        padding: "10px",
        right: "10px",
        zIndex: 1,
      }}
      onClick={onClick}
    />
  );
}

// Custom Previous Arrow
function PrevArrow(props) {
  const { className, style, onClick } = props;
  return (
    <div
      className={className}
      style={{
        ...style,
        display: "block",
        borderRadius: "50%",
        padding: "10px",
        left: "10px",
        zIndex: 1,
      }}
      onClick={onClick}
    />
  );
}

const HomePageSlider = () => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
    nextArrow: <NextArrow />,
    prevArrow: <PrevArrow />,
  };

  return (
    <div className="slider-container">
      <Slider {...settings}>
        <div>
          <img src={blenderImage} alt="Green Lion Blender" />
        </div>
        <div>
          <img src={bottlesImage} alt="Green Lion Bottles" />
        </div>
        <div>
          <img src={christmasBanner} alt="Christmas Banner" />
        </div>
        <div>
          <img src={earbudsImage} alt="Earbuds" />
        </div>
        <div>
          <img src={gimbalImage} alt="Gimbal" />
        </div>
        <div>
          <img src={watchImage} alt="Smart Watch" />
        </div>
        <div>
          <img src={warrantyImage} alt="Warranty" />
        </div>
      </Slider>
    </div>
  );
};

export default HomePageSlider;
