import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import HomePage from "./components/pages/HomePage";
import ShopPage from "./components/pages/ShopPage";
import BulkPurchasePage from "./components/pages/BulkPurchasePage";
import AboutPage from "./components/pages/AboutPage";
import BlogPage from "./components/pages/BlogPage";
import ContactUsPage from "./components/pages/ContactUsPage";
import Cart from "./components/pages/Cart";
import Search from './components/pages/Search';
import Signin from './components/pages/Signin';
import GreenLionDistribution from "./components/GreenLionDistribution/GreenLionDistribution";
import GroomingProducts from './components/Shop/category/GroomingProducts';


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/shop" element={<ShopPage />} />
        <Route path="/shop/category/grooming-products-68" element={<GroomingProducts />} />
        <Route path="/bulk-purchase" element={<BulkPurchasePage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/blog" element={<BlogPage />} />
        <Route path="/contact-us" element={<ContactUsPage />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/search" element={<Search />} />  
        <Route path="/Signin" element={<Signin />} />  
        <Route path="/GreenLionDistribution" element={<GreenLionDistribution />} />
      </Routes>
    </Router>
  );
}

export default App;
